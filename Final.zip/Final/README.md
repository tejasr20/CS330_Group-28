# CS330_Group-28
Assignments for CS330: Operating Systems, Fall Semester '22-'23<br/>
Members:<br/>
> Aryan Vora: 200204<br/>
> Pradeep: 200826<br/>
> Tejas Ramakrishnan: 201050<br/>
> Yash Gupta: 201144<br/>
