#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"
#include<stddef.h>

int main() {
    int b=fork();
	// int p[2];
	// if (pipe(p) < 0)
	// 	exit(1);
    if(b==0) {
        printf("Hello, I am child and my pid is %d\n", getpid());
		// close(p[0]);
		// int msg1 = getpid();
		// int msg1 = 42;
		// write(p[1], &msg1, sizeof(msg1));
		// close(p[1]);
    }
    else {
        // waitpid(-1,0);
		// int pid;
		waitpid(-1, 0);
		// close(p[1]);
	    // read(p[0], &pid, sizeof(pid));
		// printf("Parent receives child pid from pipe to be %d", pid);
		// waitpid(pid, 0);
		// close(p[0]);
        printf("hello i am parent\n");
    }
    exit(0);
}
