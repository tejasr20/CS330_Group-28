First Assignment: 4 files in xv6
